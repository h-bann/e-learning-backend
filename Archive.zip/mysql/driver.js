const mysql = require("mysql");
const {
  insertCourses,
  insertModules,
  insertSubModules,
  insertContent,
} = require("../mysql/queries");
// const data = require("../courseContent.json");

// ! When using local database
// const connection = mysql.createConnection({
//   host: process.env.DB_LOCALHOST,
//   user: process.env.DB_LOCALUSER,
//   password: process.env.DB_LOCALPASSWORD,
//   database: process.env.DB_LOCALDATABASE,
//   multipleStatements: false,
// });

// ! When using host presto database
const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
});

console.log(process.env);
connection.connect((error) => {
  if (error) {
    console.error("Error connecting to database:", error);
  }
});

function mySQL(query, params) {
  return new Promise((resolve, reject) => {
    connection.query(query, params, (error, results) => {
      if (error) {
        reject(error);
        return;
      }
      resolve(results);
    });
  });
}

module.exports = mySQL;

// ! Inserts data into database
//
// insertData();
